Slot E-registration Demonstration V6 Build 349
================================================


Welcome to CrypKey's E-Registration Demonstration!

The purpose of this document and demonstration is to give you first hand knowledge and experience with an exciting new way to deliver and protect software.


What is E-Registration?
=======================

E-Registration, or Electronic Registration, is an automated way to enable software for a specific computer. The process simple in concept: 

  1) Software is shipped with a serial number
  2) User types in the serial number during install or first run
  3) Using the Internet, Serial number is immediately checked to be valid and not used before
  4) If serial number is valid, software is enabled for the User's computer

The Electronic Registration insures the software is enable only on 1 computer, and the serial number cannot be reused.

Why do I need E-Registration?
=============================

You are a company that makes software. You have invested real money into creating the software, and you want and deserve to see a return on your investment.

However, you face a modern problem - software can be copied by anyone. 

This problem threatens your investment, because where is the value of something that anyone can have - for free?

The are other solutions available, but they cost you too much time and money to support, but much worse, they cost your customer, burdening your customer with inconveniences that drive them away.

You need a modern solution to a modern problem.

CrypKey's E-Register solves this problem using modern technology. By marrying Internet technology to CrypKey's multiple award winning copy protection, we have created a solution that is functional, affordable, and most importantly, extremely customer friendly.

CrypKey's E-Register converts your software, a bunch of very copy-able electronic bits, into "RealWare", a product that can only be used by the people you allow.


CrypKey E-Register protects and optimizes your software investment.


How to use this Demo
=====================

1) Copy SlotEREG.EXE to a new directory and run it.
2) When the license dialog comes up, click the "Electronic Registration" button
3) Click "Next" until you are asked for a serial number, then enter the serial number "123"

E-Register, in a matter of seconds, will cross the Internet to our server at CrypKey Head Office in Calgary, Alberta. The serial number will be verified, and a license specific to your computer generated. The license is sent back over to the Internet and automatically entered into the software on your computer, activating it for 3 days.

This serial number has been allowed 1,000,000 copies, but your serial numbers would normally allow only 1, guaranteeing 1 copy per customer.

Enjoy the Slot Machine Game!


Best Regards,
Jim McCartney
CEO CrypKey (Canada) Inc.


For more Information:
=====================

Email CrypKey!   info@crypkey.com
Phone CrypKey!   403-258-6274
Browse CrypKey!  www.crypkey.com
Visit CrypKey!   Suite 200, 908 17Ave. S.W. Calgary, Alberta, Canada T2A 0A3

Contact us today!

